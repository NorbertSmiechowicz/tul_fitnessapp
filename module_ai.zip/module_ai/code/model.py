import torch.nn as nn
import torch.nn.functional as F


class RNN(nn.Module):
    def __init__(self):

        super(RNN, self).__init__()

        


    def forward(self, out):
        pass

        return out